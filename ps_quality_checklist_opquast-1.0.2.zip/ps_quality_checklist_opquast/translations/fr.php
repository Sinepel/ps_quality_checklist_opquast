<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ps_quality_checklist_opquast}prestashop>ps_quality_checklist_opquast_735c65e4e56f0677f94ea6da9c360736'] = 'Prestashop Quality Checklist Opquast';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>ps_quality_checklist_opquast_1fda7bb60e067fe69238fb9311be0f30'] = 'Checklist qualité web Opquast pour Prestashop';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>ps_quality_checklist_opquast_96d4dadd096605d5813d2c6bdf82e82c'] = 'Paramètres enregstrés';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>ps_quality_checklist_opquast_0d12d71da532bbf5d2e33b89b76ab303'] = 'Une erreur est survenue. Veuillez réessayer';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_8a8d73d0896163cc23a7ec6a73ce2683'] = 'Vos stats';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_a9f971e06d50cf32eac3b7f65398c1b0'] = 'Opquast Quality Checklist';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_1684cd0b4368f2751cc86c016ecd3ff2'] = 'Trier par thème';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_1d00e7dce692e8dc3f6877f035e3a616'] = 'Ou';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_780e9f5c8bcf0d313d3d4b53b82f6527'] = 'Trier par statut';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_952358fc53c0167a1ea7354f338ed5af'] = 'Conforme';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_e5ce6fb9bcfd5efd8c96ce77dc09563a'] = 'Non conforme';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_49987736333e0347e4d1494ceba3fb2f'] = 'Non applicable';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_d5ca088299d5908ca359f17692071761'] = 'Non vérifié';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_12c74214cb4c18cf36d885303d6aa2e1'] = 'Objectif';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_49b21ad0d38942f635877e7bbc5d7a1e'] = 'Mise en œuvre';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_a1595abbb4c3a326636dd178757cd6c1'] = 'Contrôle';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_eda45e38eb69171d1a9d8775db1e2d72'] = 'Voir le détail sur le site OPQuast';
$_MODULE['<{ps_quality_checklist_opquast}prestashop>index_2b43350df7a639621df6257e4d340983'] = 's\'ouvre dans un nouvel onglet';
